---
title: End To End Machine Learning
emoji: 🐢
colorFrom: pink
colorTo: blue
sdk: gradio
sdk_version: 5.21.0
app_file: app.py
pinned: false
license: apache-2.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
